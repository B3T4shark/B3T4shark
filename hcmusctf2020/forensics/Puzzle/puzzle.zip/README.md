Left to Right, Bottom to Top.
Throw all digits, the flag will appear.
Seek the origin: https://www.hcmus.edu.vn/images/2020/04/07/bn2.jpg

Author: may